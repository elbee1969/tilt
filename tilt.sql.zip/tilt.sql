--
-- Base de données :  `tilt`
--

-- --------------------------------------------------------

--
-- Structure de la table `tilt_competences_generales`
--

CREATE TABLE `tilt_competences_generales` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_competences_generales`
--

INSERT INTO `tilt_competences_generales` (`id`, `name`) VALUES
(1, 'arts'),
(2, 'chimie'),
(3, 'cuisine'),
(4, 'economie'),
(5, 'français'),
(6, 'geographie'),
(7, 'histoire'),
(8, 'langues etrangeres'),
(9, 'mathematiques'),
(10, 'musique'),
(11, 'nouvelles technologies'),
(12, 'physique'),
(13, 'sport');

-- --------------------------------------------------------

--
-- Structure de la table `tilt_competences_particulieres`
--

CREATE TABLE `tilt_competences_particulieres` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `competences_generales_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_competences_particulieres`
--

INSERT INTO `tilt_competences_particulieres` (`id`, `name`, `competences_generales_id`) VALUES
(1, 'dessin', 1),
(2, 'peinture', 1),
(3, 'photographie', 1),
(4, 'sculpture', 1),
(5, 'moleculaire', 2),
(6, 'organique', 2),
(7, 'petrochimie', 2),
(8, 'biochimie', 2),
(9, 'boulangerie', 3),
(10, 'moléculaire', 3),
(11, 'patisserie', 3),
(12, 'verrines', 3),
(13, 'internationale', 4),
(14, 'macroeconomie', 4),
(15, 'microeconomie', 4),
(16, 'nationale', 4),
(17, 'conjugaison', 5),
(18, 'grammaire', 5),
(19, 'orthographe', 5),
(20, 'syntaxe', 5),
(21, 'fleuves/rivieres', 6),
(22, 'forets', 6),
(23, 'mondiale', 6),
(24, 'nationale', 6),
(25, 'conflits internationaux', 7),
(26, 'histoire de France', 7),
(27, 'moyen-age', 7),
(28, 'prehistoire', 7),
(29, 'allemand', 8),
(30, 'anglais', 8),
(31, 'espagnol', 8),
(32, 'russe', 8),
(33, 'arithmetique', 9),
(34, 'geometrie', 9),
(35, 'statistiques', 9),
(36, 'trigonometrie', 9),
(37, 'flute traversiere', 10),
(38, 'guitare', 10),
(39, 'piano', 10),
(40, 'solfege', 10),
(41, 'developpement informatique', 11),
(42, 'intelligence artificielle', 11),
(43, 'objets connectes', 11),
(44, 'robotique', 11),
(45, 'mecanique des fluides', 12),
(46, 'nucleaire', 12),
(47, 'quantique', 12),
(48, 'science des materiaux', 12),
(49, 'athletisme', 13),
(50, 'boxe', 13),
(51, 'karate', 13),
(52, 'tae-kwon-doe', 13);

-- --------------------------------------------------------

--
-- Structure de la table `tilt_formations`
--

CREATE TABLE `tilt_formations` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tilt_regions`
--

CREATE TABLE `tilt_regions` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_regions`
--

INSERT INTO `tilt_regions` (`id`, `name`, `slug`) VALUES
(1, 'alsace', 'alsace'),
(2, 'aquitaine', 'aquitaine'),
(3, 'auvergne', 'auvergne'),
(4, 'basse normandie', 'basse_normandie'),
(5, 'bourgogne', 'bourgogne'),
(6, 'bretagne', 'bretagne'),
(7, 'centre val de loire', 'centre_val_de_loire'),
(8, 'champagne-ardenne', 'champagne_ardenne'),
(9, 'corse', 'corse'),
(10, 'franche-comté', 'franche_comte'),
(11, 'haute normandie', 'haute_normandie'),
(12, 'île de france', 'ile_de_france'),
(13, 'languedoc roussillon', 'languedoc_roussillon'),
(14, 'limousin', 'limousin'),
(15, 'lorraine', 'lorraine'),
(16, 'midi-pyrénées', 'midi_pyrenees'),
(17, 'nord-pas-de-calais', 'nord_pas_de_calais'),
(18, 'pays de la loire', 'pays_de_la_loire'),
(19, 'picardie', 'picardie'),
(20, 'poitou-charentes', 'poitou_charentes'),
(21, 'provence alpes côte d''azur', 'provence_alpes_cote_d_azur'),
(22, 'rhône alpes', 'rhone_alpes');

-- --------------------------------------------------------

--
-- Structure de la table `tilt_user`
--

CREATE TABLE `tilt_user` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `role` enum('apprenant','enseignant','','') NOT NULL,
  `region_id` int(11) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `avatar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `tilt_competences_generales`
--
ALTER TABLE `tilt_competences_generales`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_competences_particulieres`
--
ALTER TABLE `tilt_competences_particulieres`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_formations`
--
ALTER TABLE `tilt_formations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_regions`
--
ALTER TABLE `tilt_regions`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_user`
--
ALTER TABLE `tilt_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `tilt_competences_generales`
--
ALTER TABLE `tilt_competences_generales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `tilt_competences_particulieres`
--
ALTER TABLE `tilt_competences_particulieres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT pour la table `tilt_formations`
--
ALTER TABLE `tilt_formations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `tilt_regions`
--
ALTER TABLE `tilt_regions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT pour la table `tilt_user`
--
ALTER TABLE `tilt_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
