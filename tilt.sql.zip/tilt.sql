-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 13 Juillet 2017 à 15:25
-- Version du serveur :  10.1.21-MariaDB
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `tilt`
--

-- --------------------------------------------------------

--
-- Structure de la table `tilt_adresse`
--

CREATE TABLE `tilt_adresse` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `civilite` enum('M','Mme','Mlle','') NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `app_esc_et` varchar(150) NOT NULL,
  `bat_res` varchar(150) NOT NULL,
  `num_rue` int(5) NOT NULL,
  `compl_adresse` varchar(150) NOT NULL,
  `nom_voie` varchar(100) NOT NULL,
  `code_postal` int(5) NOT NULL,
  `ville` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_adresse`
--

INSERT INTO `tilt_adresse` (`id`, `id_user`, `civilite`, `nom`, `prenom`, `app_esc_et`, `bat_res`, `num_rue`, `compl_adresse`, `nom_voie`, `code_postal`, `ville`) VALUES
(1, 7, 'M', 'LACOUR', 'Nicolas', '2ème étage', '', 57, '', 'rue du quai', 27400, 'LOUVIERS');

-- --------------------------------------------------------

--
-- Structure de la table `tilt_avatar`
--

CREATE TABLE `tilt_avatar` (
  `id` int(11) NOT NULL,
  `name_original` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `path` varchar(250) NOT NULL,
  `mime_type` enum('jpg','jpeg','png','') NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_avatar`
--

INSERT INTO `tilt_avatar` (`id`, `name_original`, `name`, `path`, `mime_type`, `created_at`, `modified_at`) VALUES
(1, '5P6R12c.png', '1499943187-5p6r12c.png', 'assets/img/avatar/', '', '2017-07-13 12:53:07', '0000-00-00 00:00:00'),
(2, 'Poly-Lakeside.jpg', '1499943205-poly-lakeside.jpg', 'assets/img/avatar/', '', '2017-07-13 12:53:25', '0000-00-00 00:00:00'),
(3, 'rain.jpg', '1499943324-rain.jpg', 'assets/img/avatar/', '', '2017-07-13 12:55:24', '0000-00-00 00:00:00'),
(4, 'rain.jpg', '1499943498-rain.jpg', 'assets/img/avatar/', '', '2017-07-13 12:58:18', '0000-00-00 00:00:00'),
(5, 'Poly-Lakeside.jpg', '1499943575-poly-lakeside.jpg', 'assets/img/avatar/', '', '2017-07-13 12:59:35', '0000-00-00 00:00:00'),
(6, '5P6R12c.png', '1499947588-5p6r12c.png', 'assets/img/avatar/', '', '2017-07-13 14:06:28', '0000-00-00 00:00:00'),
(7, '5P6R12c.png', '1499947634-5p6r12c.png', 'assets/img/avatar/', '', '2017-07-13 14:07:14', '0000-00-00 00:00:00'),
(8, '5P6R12c.png', '1499947858-5p6r12c.png', 'assets/img/avatar/', '', '2017-07-13 14:10:58', '0000-00-00 00:00:00'),
(9, '5P6R12c.png', '1499948300-5p6r12c.png', 'assets/img/avatar/', '', '2017-07-13 14:18:20', '0000-00-00 00:00:00'),
(10, '5P6R12c.png', '1499948330-5p6r12c.png', 'assets/img/avatar/', '', '2017-07-13 14:18:50', '0000-00-00 00:00:00'),
(11, 'baptiste.jpg', '1499949130-baptiste.jpg', 'assets/img/avatar/', '', '2017-07-13 14:28:46', '2017-07-13 14:32:10'),
(12, 'laurent.jpg', '1499949202-laurent.jpg', 'assets/img/avatar/', '', '2017-07-13 14:33:22', '0000-00-00 00:00:00'),
(13, '2-jpg-tiger-hrc-siberie_21253111.jpg', '1499951955-2-jpg-tiger-hrc-siberie-21253111.jpg', 'assets/img/avatar/', '', '2017-07-13 14:50:21', '2017-07-13 15:19:15');

-- --------------------------------------------------------

--
-- Structure de la table `tilt_competences`
--

CREATE TABLE `tilt_competences` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `general` enum('arts','chimie','cuisine','economie','francais','geographie','histoire','langues','mathematiques','musique','nouvellestechnologies','physique','sport') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_competences`
--

INSERT INTO `tilt_competences` (`id`, `name`, `general`) VALUES
(1, 'dessin', 'arts'),
(2, 'peinture', 'arts'),
(3, 'photographie', 'arts'),
(4, 'sculpture', 'arts'),
(5, 'moleculaire', 'chimie'),
(6, 'organique', 'chimie'),
(7, 'petrochimie', 'chimie'),
(8, 'biochimie', 'chimie'),
(9, 'boulangerie', 'cuisine'),
(10, 'moléculaire', 'cuisine'),
(11, 'patisserie', 'cuisine'),
(12, 'verrines', 'cuisine'),
(13, 'economie internationale', 'economie'),
(14, 'macroeconomie', 'economie'),
(15, 'microeconomie', 'economie'),
(16, 'economie nationale', 'economie'),
(17, 'conjugaison', 'francais'),
(18, 'grammaire', 'francais'),
(19, 'orthographe', 'francais'),
(20, 'syntaxe', 'francais'),
(21, 'fleuves/rivieres', 'geographie'),
(22, 'forets', 'geographie'),
(23, 'geographie mondiale', 'geographie'),
(24, 'geographie nationale', 'geographie'),
(25, 'conflits internationaux', 'histoire'),
(26, 'histoire de France', 'histoire'),
(27, 'moyen-age', 'histoire'),
(28, 'prehistoire', 'histoire'),
(29, 'allemand', 'langues'),
(30, 'anglais', 'langues'),
(31, 'espagnol', 'langues'),
(32, 'russe', 'langues'),
(33, 'arithmetique', 'mathematiques'),
(34, 'geometrie', 'mathematiques'),
(35, 'statistiques', 'mathematiques'),
(36, 'trigonometrie', 'mathematiques'),
(37, 'flute traversiere', 'musique'),
(38, 'guitare', 'musique'),
(39, 'piano', 'musique'),
(40, 'solfege', 'musique'),
(41, 'developpement informatique', 'nouvellestechnologies'),
(42, 'intelligence artificielle', 'nouvellestechnologies'),
(43, 'objets connectes', 'nouvellestechnologies'),
(44, 'robotique', 'nouvellestechnologies'),
(45, 'athletisme', 'sport'),
(46, 'boxe', 'sport'),
(47, 'karate', 'sport'),
(48, 'tae-kwon-doe', 'sport');

-- --------------------------------------------------------

--
-- Structure de la table `tilt_interm`
--

CREATE TABLE `tilt_interm` (
  `user_id` int(11) NOT NULL,
  `regions_id` int(11) NOT NULL,
  `competences_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tilt_messages`
--

CREATE TABLE `tilt_messages` (
  `id` int(11) NOT NULL,
  `id_enseignant` int(11) NOT NULL,
  `id_apprenant` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL,
  `status` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_messages`
--

INSERT INTO `tilt_messages` (`id`, `id_enseignant`, `id_apprenant`, `message`, `created_at`, `status`) VALUES
(1, 1, 5, 'hello world', '2017-07-11 12:00:00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `tilt_regions`
--

CREATE TABLE `tilt_regions` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_regions`
--

INSERT INTO `tilt_regions` (`id`, `name`, `slug`) VALUES
(1, 'Auvergne-Rhône-Alpes', 'auvergne-rhone-alpes'),
(2, 'Bourgogne Franche-Comté', 'bourgogne-franche-comte'),
(3, 'Bretagne', 'bretagne'),
(4, 'Centre Val de Loire', 'centre-val-de-loire'),
(5, 'Corse', 'corse'),
(6, 'Grand EST', 'grand-est'),
(7, 'Hauts-de-France', 'hauts-de-france'),
(8, 'Ile-de-France', 'ile-de-france'),
(9, 'Normandie', 'normandie'),
(10, 'Nouvelle-Aquitaine', 'nouvelle-aquitaine'),
(11, 'Occitanie', 'occitanie'),
(12, 'Pays de la Loire', 'pays-de-la-loire'),
(13, 'Provence-Alpes-Côte d\'Azur', 'provence-alpes-cote-d-azur');

-- --------------------------------------------------------

--
-- Structure de la table `tilt_tutorat`
--

CREATE TABLE `tilt_tutorat` (
  `id` int(11) NOT NULL,
  `id_enseignant` int(11) NOT NULL,
  `id_apprenant` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tilt_user`
--

CREATE TABLE `tilt_user` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `role` enum('apprenant','enseignant','admin','guest') NOT NULL,
  `region_id` int(11) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `avatar` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime NOT NULL,
  `token` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `tilt_user`
--

INSERT INTO `tilt_user` (`id`, `first_name`, `last_name`, `role`, `region_id`, `pseudo`, `avatar`, `email`, `password`, `created_at`, `modified_at`, `token`, `status`) VALUES
(1, 'nicolas', 'lacour', 'admin', 3, 'niko', 0, 'bat.crestey@gmail.com', '$2y$10$EKOC.WaZIu8.cvESWSaHmORAqf0JT2NR3YTcGkqKLt.LE79G5DDq6', '2017-07-02 00:00:00', '0000-00-00 00:00:00', 'SFIy1NZYQ_yUFGZKyycYXpr7yXDaWYPybmRDkISHKkuLD4JXwthZwy1CnQjlWeSllpjgcGe4q8WdmaMe', 1),
(2, 'alphonse', 'nom', 'enseignant', 8, 'alph', 0, '', '', '2017-07-03 00:00:00', '0000-00-00 00:00:00', '', 1),
(3, 'jeanclaude', 'vand', 'apprenant', 12, 'jcvd', 0, '', '', '2017-06-14 00:00:00', '0000-00-00 00:00:00', '', 1),
(4, 'jeanlouis', 'fdztws', 'apprenant', 4, 'jeanl', 0, '', '', '2017-05-03 00:00:00', '0000-00-00 00:00:00', '', 1),
(5, 'Baptiste', 'Crestey', 'admin', 9, 'baptisteCG', 11, 'baptiste.cresteyg@gmail.com', '$2y$10$QyNoNjm5JFZwjLgjJpxDD.DUxZxbW1n37rt76TG7JvuIwtkC.siGq', '2017-07-12 17:02:27', '0000-00-00 00:00:00', 'MHCwTCWxiMiHSCzFv-d1bnPw8fN25gCfy_wfMGyRwYSvf2i8KwIaTyWaJ3XgLHghzvYyvelmo8cWRlBT', 1),
(6, 'lolilol', 'lolilol', 'guest', 7, 'lolilol', 12, 'gdsfhj@fjdkgj.com', '$2y$10$rd1x5HLb.FDm.447Yh4L7OS3AJ8kzvwETYI/wjM.GygaTw7IXlUkq', '2017-07-13 11:59:09', '0000-00-00 00:00:00', '6R6Bd9218dAQSlZ3i1dXPJL8GEz0SPcIT6bUoX0SV1Hft4SzP16M9hSgM7TLB8ktRxYIawWtKA7Mc35G', 1),
(7, 'tilt', 'tilt', 'guest', 9, 'tilt', 13, 'tilt@auptisommelier.fr', '$2y$10$hr10E4dhInD6LbeL8W3uvOTgKvlqXjifj6iTRAsUHVMo0Nyk/wIsm', '2017-07-13 14:49:30', '0000-00-00 00:00:00', '5h2Epbisfzr0S1QKFzg6ASb4dWc7RUFY3yyb7P_rFYrxIAsb4d4PNwQfvLFEPsKT36jjpLds0938UvsF', 1);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `tilt_adresse`
--
ALTER TABLE `tilt_adresse`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_avatar`
--
ALTER TABLE `tilt_avatar`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_competences`
--
ALTER TABLE `tilt_competences`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_messages`
--
ALTER TABLE `tilt_messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_regions`
--
ALTER TABLE `tilt_regions`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_tutorat`
--
ALTER TABLE `tilt_tutorat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tilt_user`
--
ALTER TABLE `tilt_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `tilt_adresse`
--
ALTER TABLE `tilt_adresse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `tilt_avatar`
--
ALTER TABLE `tilt_avatar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `tilt_competences`
--
ALTER TABLE `tilt_competences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT pour la table `tilt_messages`
--
ALTER TABLE `tilt_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `tilt_regions`
--
ALTER TABLE `tilt_regions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `tilt_tutorat`
--
ALTER TABLE `tilt_tutorat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `tilt_user`
--
ALTER TABLE `tilt_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
